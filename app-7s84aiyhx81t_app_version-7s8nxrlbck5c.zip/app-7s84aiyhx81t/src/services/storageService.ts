import type { GuardianContact, AppSettings, SOSEvent } from '@/types/panicsafe';

class StorageService {
  private readonly GUARDIANS_KEY = 'panicsafe_guardians';
  private readonly SETTINGS_KEY = 'panicsafe_settings';
  private readonly SOS_HISTORY_KEY = 'panicsafe_sos_history';

  // Guardian Management
  getGuardians(): GuardianContact[] {
    const data = localStorage.getItem(this.GUARDIANS_KEY);
    if (!data) return [];
    
    const guardians = JSON.parse(data);
    return guardians.map((g: GuardianContact) => ({
      ...g,
      addedAt: new Date(g.addedAt)
    }));
  }

  addGuardian(guardian: GuardianContact): void {
    const guardians = this.getGuardians();
    guardians.push(guardian);
    localStorage.setItem(this.GUARDIANS_KEY, JSON.stringify(guardians));
  }

  removeGuardian(id: string): void {
    const guardians = this.getGuardians().filter(g => g.id !== id);
    localStorage.setItem(this.GUARDIANS_KEY, JSON.stringify(guardians));
  }

  updateGuardian(id: string, updates: Partial<GuardianContact>): void {
    const guardians = this.getGuardians().map(g => 
      g.id === id ? { ...g, ...updates } : g
    );
    localStorage.setItem(this.GUARDIANS_KEY, JSON.stringify(guardians));
  }

  // Settings Management
  getSettings(): AppSettings {
    const data = localStorage.getItem(this.SETTINGS_KEY);
    if (!data) {
      return this.getDefaultSettings();
    }
    return JSON.parse(data);
  }

  saveSettings(settings: AppSettings): void {
    localStorage.setItem(this.SETTINGS_KEY, JSON.stringify(settings));
  }

  private getDefaultSettings(): AppSettings {
    return {
      fingerprintEnabled: false,
      calculatorModeEnabled: false,
      voiceActivationEnabled: true,
      voiceKeywords: ['help me', 'save me', 'emergency'],
      shakeGestureEnabled: true,
      autoRecordingEnabled: true,
      flashAlertEnabled: true,
      vibrationEnabled: true
    };
  }

  // SOS History
  getSOSHistory(): SOSEvent[] {
    const data = localStorage.getItem(this.SOS_HISTORY_KEY);
    if (!data) return [];
    
    const events = JSON.parse(data);
    return events.map((e: SOSEvent) => ({
      ...e,
      timestamp: new Date(e.timestamp),
      location: {
        ...e.location,
        timestamp: new Date(e.location.timestamp)
      }
    }));
  }

  addSOSEvent(event: SOSEvent): void {
    const history = this.getSOSHistory();
    history.unshift(event);
    
    // Keep only last 50 events
    const trimmed = history.slice(0, 50);
    localStorage.setItem(this.SOS_HISTORY_KEY, JSON.stringify(trimmed));
  }

  // Clear All Data
  clearAllData(): void {
    localStorage.removeItem(this.GUARDIANS_KEY);
    localStorage.removeItem(this.SETTINGS_KEY);
    localStorage.removeItem(this.SOS_HISTORY_KEY);
  }
}

export const storageService = new StorageService();
