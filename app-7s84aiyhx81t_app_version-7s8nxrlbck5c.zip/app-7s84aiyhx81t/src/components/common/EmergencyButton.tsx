import { useState } from 'react';
import { AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { sosService } from '@/services/sosService';

interface EmergencyButtonProps {
  size?: 'sm' | 'md' | 'lg';
  onSOSTriggered?: () => void;
}

export default function EmergencyButton({ size = 'lg', onSOSTriggered }: EmergencyButtonProps) {
  const [countdown, setCountdown] = useState<number | null>(null);
  const { toast } = useToast();

  const handlePress = () => {
    sosService.startCountdown(3, (remaining) => {
      setCountdown(remaining);
      
      if (remaining === 0) {
        setCountdown(null);
        toast({
          title: "SOS Activated",
          description: "Emergency alert sent to all guardians",
          variant: "destructive"
        });
        onSOSTriggered?.();
      }
    });
  };

  const handleRelease = () => {
    if (countdown !== null && countdown > 0) {
      sosService.stopCountdown();
      setCountdown(null);
      toast({
        title: "SOS Cancelled",
        description: "Emergency alert was cancelled"
      });
    }
  };

  const sizeClasses = {
    sm: 'w-24 h-24 text-lg',
    md: 'w-32 h-32 text-xl',
    lg: 'w-48 h-48 text-2xl'
  };

  return (
    <div className="flex flex-col items-center gap-4">
      <Button
        size="lg"
        onMouseDown={handlePress}
        onMouseUp={handleRelease}
        onTouchStart={handlePress}
        onTouchEnd={handleRelease}
        className={`${sizeClasses[size]} rounded-full bg-emergency hover:bg-emergency/90 text-emergency-foreground font-bold shadow-lg ${
          countdown !== null ? 'animate-pulse-emergency' : ''
        }`}
      >
        {countdown !== null ? (
          <span className="text-4xl">{countdown}</span>
        ) : (
          <div className="flex flex-col items-center">
            <AlertCircle className="w-12 h-12 mb-2" />
            <span>SOS</span>
          </div>
        )}
      </Button>
      
      {countdown !== null && (
        <p className="text-sm text-muted-foreground animate-pulse">
          Release to cancel...
        </p>
      )}
    </div>
  );
}
