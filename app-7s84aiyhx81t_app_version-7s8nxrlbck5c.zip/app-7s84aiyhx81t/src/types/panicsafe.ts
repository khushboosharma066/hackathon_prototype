// PanicSafe Type Definitions

export interface GuardianContact {
  id: string;
  name: string;
  phone: string;
  email?: string;
  relationship: string;
  isSharing: boolean;
  addedAt: Date;
}

export interface Location {
  latitude: number;
  longitude: number;
  accuracy?: number;
  timestamp: Date;
}

export interface SafeZone {
  id: string;
  name: string;
  type: 'police' | 'hospital' | 'safe_hub';
  location: Location;
  address: string;
  phone?: string;
  distance?: number;
}

export interface SOSEvent {
  id: string;
  timestamp: Date;
  location: Location;
  guardians: string[];
  dangerLevel: DangerLevel;
  resolved: boolean;
  videoRecorded: boolean;
  audioRecorded: boolean;
}

export type DangerLevel = 'safe' | 'low' | 'medium' | 'high' | 'critical';

export interface ThreatDetection {
  type: 'stranger' | 'following' | 'aggressive' | 'weapon' | 'group';
  confidence: number;
  timestamp: Date;
}

export interface AIDetectionResult {
  dangerScore: number;
  dangerLevel: DangerLevel;
  threats: ThreatDetection[];
  isMonitoring: boolean;
}

export interface AppSettings {
  pinCode?: string;
  fingerprintEnabled: boolean;
  calculatorModeEnabled: boolean;
  voiceActivationEnabled: boolean;
  voiceKeywords: string[];
  shakeGestureEnabled: boolean;
  autoRecordingEnabled: boolean;
  flashAlertEnabled: boolean;
  vibrationEnabled: boolean;
}

export interface PatrolZone {
  id: string;
  area: string;
  status: 'active' | 'inactive';
  lastUpdate: Date;
}

export interface FakeCallConfig {
  contactName: string;
  delaySeconds: number;
  ringtoneEnabled: boolean;
}
