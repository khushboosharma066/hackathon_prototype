import { useState, useEffect } from 'react';
import { MapPin, Navigation, Phone, Share2, Shield } from 'lucide-react';
import BottomNav from '@/components/common/BottomNav';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { locationService } from '@/services/locationService';
import type { Location, SafeZone } from '@/types/panicsafe';

export default function MapPage() {
  const [userLocation, setUserLocation] = useState<Location | null>(null);
  const [isSharing, setIsSharing] = useState(false);
  const { toast } = useToast();

  const safeZones: SafeZone[] = [
    {
      id: '1',
      name: 'Central Police Station',
      type: 'police',
      location: { latitude: 40.7589, longitude: -73.9851, timestamp: new Date() },
      address: '123 Main St, New York, NY 10001',
      phone: '(555) 123-4567'
    },
    {
      id: '2',
      name: 'City General Hospital',
      type: 'hospital',
      location: { latitude: 40.7614, longitude: -73.9776, timestamp: new Date() },
      address: '456 Health Ave, New York, NY 10002',
      phone: '(555) 234-5678'
    },
    {
      id: '3',
      name: 'Community Safe Hub',
      type: 'safe_hub',
      location: { latitude: 40.7505, longitude: -73.9934, timestamp: new Date() },
      address: '789 Safety Blvd, New York, NY 10003',
      phone: '(555) 345-6789'
    },
    {
      id: '4',
      name: 'North Precinct',
      type: 'police',
      location: { latitude: 40.7689, longitude: -73.9800, timestamp: new Date() },
      address: '321 North St, New York, NY 10004',
      phone: '(555) 456-7890'
    },
    {
      id: '5',
      name: 'Emergency Medical Center',
      type: 'hospital',
      location: { latitude: 40.7450, longitude: -73.9900, timestamp: new Date() },
      address: '654 Care Lane, New York, NY 10005',
      phone: '(555) 567-8901'
    }
  ];

  useEffect(() => {
    loadLocation();
  }, []);

  const loadLocation = async () => {
    try {
      const location = await locationService.getCurrentLocation();
      setUserLocation(location);
      
      // Calculate distances
      safeZones.forEach(zone => {
        zone.distance = locationService.calculateDistance(location, zone.location);
      });
    } catch (error) {
      toast({
        title: "Location Error",
        description: "Could not access your location",
        variant: "destructive"
      });
    }
  };

  const toggleLocationSharing = () => {
    if (isSharing) {
      locationService.stopWatchingLocation();
      setIsSharing(false);
      toast({
        title: "Sharing Stopped",
        description: "Location sharing has been disabled"
      });
    } else {
      locationService.startWatchingLocation((location) => {
        setUserLocation(location);
      });
      setIsSharing(true);
      toast({
        title: "Sharing Active",
        description: "Your live location is being shared"
      });
    }
  };

  const navigateToZone = (zone: SafeZone) => {
    const url = `https://www.google.com/maps/dir/?api=1&destination=${zone.location.latitude},${zone.location.longitude}`;
    window.open(url, '_blank');
  };

  const getZoneIcon = (type: string) => {
    switch (type) {
      case 'police':
        return '🛡️';
      case 'hospital':
        return '🏥';
      case 'safe_hub':
        return '🏢';
      default:
        return '📍';
    }
  };

  const sortedZones = [...safeZones].sort((a, b) => 
    (a.distance || 0) - (b.distance || 0)
  );

  return (
    <div className="min-h-screen bg-background pb-20">
      <div className="bg-foreground text-background p-4">
        <div className="flex items-center gap-2">
          <MapPin className="w-6 h-6" />
          <h1 className="text-xl font-bold">Map & Safe Zones</h1>
        </div>
      </div>

      <div className="p-4 space-y-4">
        <div className="bg-muted rounded-lg p-8 text-center">
          <MapPin className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
          <p className="text-sm text-muted-foreground mb-2">Your Location</p>
          {userLocation ? (
            <div className="text-xs font-mono">
              <p>{userLocation.latitude.toFixed(6)}, {userLocation.longitude.toFixed(6)}</p>
              <p className="text-muted-foreground mt-1">
                Accuracy: ±{userLocation.accuracy?.toFixed(0)}m
              </p>
            </div>
          ) : (
            <p className="text-sm">Loading...</p>
          )}
        </div>

        <Button
          className="w-full"
          onClick={toggleLocationSharing}
          variant={isSharing ? "destructive" : "default"}
        >
          <Share2 className="w-4 h-4 mr-2" />
          {isSharing ? 'Stop Sharing Location' : 'Share Live Location'}
        </Button>

        <div>
          <h2 className="text-lg font-semibold mb-3 flex items-center gap-2">
            <Shield className="w-5 h-5 text-safe" />
            Nearest Safe Zones
          </h2>
          
          <div className="space-y-3">
            {sortedZones.map((zone) => (
              <Card key={zone.id}>
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    <span className="text-3xl">{getZoneIcon(zone.type)}</span>
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold">{zone.name}</h3>
                      <p className="text-sm text-muted-foreground mt-1">
                        {zone.address}
                      </p>
                      {zone.distance && (
                        <Badge variant="outline" className="mt-2">
                          {zone.distance.toFixed(2)} km away
                        </Badge>
                      )}
                    </div>
                  </div>
                  
                  <div className="flex gap-2 mt-3">
                    <Button
                      size="sm"
                      className="flex-1"
                      onClick={() => navigateToZone(zone)}
                    >
                      <Navigation className="w-4 h-4 mr-2" />
                      Navigate
                    </Button>
                    {zone.phone && (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => window.location.href = `tel:${zone.phone}`}
                      >
                        <Phone className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        <Card className="bg-warning/10 border-warning">
          <CardContent className="p-4">
            <h3 className="font-semibold text-sm mb-2">Crime Heatmap Legend</h3>
            <div className="flex items-center gap-4 text-xs">
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 bg-safe rounded" />
                <span>Safe</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 bg-danger-medium rounded" />
                <span>Moderate</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 bg-danger-critical rounded" />
                <span>High Risk</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <BottomNav />
    </div>
  );
}
