# PanicSafe Mobile App Requirements Document

## 1. Application Overview

### 1.1 Application Name
PanicSafe

### 1.2 Application Description
A comprehensive women's safety mobile application featuring AI-powered danger prediction, emergency response system, and real-time guardian tracking. The app provides fast emergency help, predictive alerts, real-time danger analysis, and automatic SOS actions to ensure user safety in critical situations.

### 1.3 Target Platform
Mobile Application (iOS & Android)

### 1.4 Technology Stack
Flutter or React Native

## 2. Core Features
\n### 2.1 Dual SOS Trigger System
- Large, prominent SOS button displayed on home screen
- Voice activation support with keywords: 'Help me', 'Save me', and similar emergency phrases
- 3-second countdown mechanism before SOS activation to prevent accidental triggers

### 2.2 Emergency Workflow
- Automatically send live location to pre-configured guardian contacts
- Transmit location data and danger level assessment to backup server via API
- SMS fallback mechanism for offline scenarios
- Initiate background audio recording upon SOS activation
- Start automatic video recording using front-facing camera
- Flash light and vibration alerts for user confirmation

### 2.3 AI Danger Prediction Camera
- Real-time monitoring using both front and back cameras
- Detect potential threats including:
  - Strangers in close proximity
  - Following behavior patterns
  - Aggressive facial expressions
  - Weapon gesture recognition
  - Suspicious group activities
- Automated response when danger threshold exceeded:\n  - Device vibration alert
  - Automatic 10-second video recording
  - SOS countdown initiation
  - Display'Possible Threat Detected' warning message
- Complete UI implementation with ML model integration placeholders, camera pipeline, and danger scoring system

### 2.4 Live Guardian Tracking\n- Guardian contact management (add/remove functionality)
- One-tap 'Share My Live Location' feature
- Interactive map view displaying user's real-time moving location

### 2.5 Map & Safe Zone Navigator
- Display nearest safety locations:
  - Police stations
  - Hospitals
  - Public safe hubs
- Auto-navigation routing to selected safe zones
- Emergency walk-home route planning

### 2.6 Fake Call System
- Realistic incoming call simulation from customizable contacts ('Mom', 'Police Officer', or custom names)
- Authentic UI design with ringtone\n- Multiple trigger methods:
  - Hidden button activation
  - Voice code phrase\n  - Shake gesture detection

### 2.7 Routine Anomaly AI
- Daily route learning system (placeholder implementation)
- Alert triggers for unusual patterns:\n  - Extended stops in unsafe areas
  - Deviation from usual routes
  - Unusual late-night movement

### 2.8 Police Patrolling Map
- Live patrolling zones visualization
- Crime heatmap overlay with dummy data
- Police patrol check request functionality

### 2.9 Privacy & Security\n- Panic Mode Quick Access via long-press power button
- PIN and fingerprint authentication for app access
- Encrypted storage for media evidence
- Fake 'Calculator Mode' to disguise app appearance

### 2.10 User Interface Pages
**Page 1: Home Screen**
- Large SOS button with voice activation indicator
- Quick access to all major features
\n**Page 2: AI Danger Camera**
- Real-time camera preview with threat detection overlay
- Danger level indicator\n- Detection status display

**Page 3: Map & Safe Zones**
- Interactive map with user location
- Safety location markers (police stations, hospitals, safe hubs)
- Navigation controls

**Page 4: Guardian Contacts**
- Guardian list management
- Live location sharing controls
- Contact details and communication options

**Page 5: Settings & Privacy**
- Security settings (PIN, fingerprint)\n- Privacy mode configurations
- App preferences and customization

## 3. Technical Implementation Requirements

### 3.1 Navigation\n- Functional navigation system between all five main screens
- Smooth transitions and intuitive user flow
\n### 3.2 Camera Integration
- Working camera preview for both front and rear cameras
- Background recording capability placeholders
\n### 3.3 Map Integration
- Interactive map with custom markers\n- Real-time location tracking
- Route navigation functionality

### 3.4 SOS System
- Complete SOS workflow implementation with mock API endpoints
- Background audio/video recording placeholders
\n### 3.5 AI Pipeline
- AI inference pipeline placeholder structure
- Danger detection algorithm framework
\n### 3.6 Code Deliverables
- Export-ready, production-quality code
- Modular architecture for easy maintenance
\n## 4. Design Style\n
### 4.1 Overall Design Approach
- Super minimal, clean, and modern interface design
- High-contrast panic UI utilizing red and white color scheme for emergency visibility
- Large, easily accessible buttons with no visual clutter
- Speed-optimized design for emergency situations

### 4.2 Color Scheme
- Primary emergency color: Bright red (#FF0000) for SOS and alert elements
- Secondary color: Pure white (#FFFFFF) for contrast and clarity
- Neutral colors: Dark gray (#333333) for text, light gray (#F5F5F5) for backgrounds\n- Success indicators: Green (#4CAF50) for safe status\n
### 4.3 Visual Elements
- Rounded corners (8px radius) for modern, friendly appearance
- Subtle shadows for depth and hierarchy
- Bold, sans-serif typography for readability
- Icon-driven navigation with clear labels
- Smooth animations for state transitions

### 4.4 Layout Structure
- Card-based layout for feature modules
- Bottom navigation bar for main sections
- Floating action button for quick SOS access
- Full-screen emergency mode with minimal distractions