import HomePage from './pages/HomePage';
import CameraPage from './pages/CameraPage';
import MapPage from './pages/MapPage';
import GuardiansPage from './pages/GuardiansPage';
import SettingsPage from './pages/SettingsPage';
import FakeCallPage from './pages/FakeCallPage';
import type { ReactNode } from 'react';

interface RouteConfig {
  name: string;
  path: string;
  element: ReactNode;
  visible?: boolean;
}

const routes: RouteConfig[] = [
  {
    name: 'Home',
    path: '/',
    element: <HomePage />
  },
  {
    name: 'AI Danger Camera',
    path: '/camera',
    element: <CameraPage />
  },
  {
    name: 'Map & Safe Zones',
    path: '/map',
    element: <MapPage />
  },
  {
    name: 'Guardian Contacts',
    path: '/guardians',
    element: <GuardiansPage />
  },
  {
    name: 'Settings',
    path: '/settings',
    element: <SettingsPage />
  },
  {
    name: 'Fake Call',
    path: '/fake-call',
    element: <FakeCallPage />
  }
];

export default routes;