import { useState, useEffect } from 'react';
import { Settings as SettingsIcon, Lock, Mic, Smartphone, Calculator, Video, Zap, Vibrate, Shield } from 'lucide-react';
import BottomNav from '@/components/common/BottomNav';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/hooks/use-toast';
import { storageService } from '@/services/storageService';
import type { AppSettings } from '@/types/panicsafe';

export default function SettingsPage() {
  const [settings, setSettings] = useState<AppSettings>(storageService.getSettings());
  const [pinCode, setPinCode] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const { toast } = useToast();

  useEffect(() => {
    const loaded = storageService.getSettings();
    setSettings(loaded);
    if (loaded.pinCode) {
      setPinCode('****');
    }
  }, []);

  const updateSetting = <K extends keyof AppSettings>(key: K, value: AppSettings[K]) => {
    const updated = { ...settings, [key]: value };
    setSettings(updated);
    storageService.saveSettings(updated);
    
    toast({
      title: "Settings Updated",
      description: "Your preferences have been saved"
    });
  };

  const handleSetPin = () => {
    if (pinCode.length < 4) {
      toast({
        title: "Invalid PIN",
        description: "PIN must be at least 4 digits",
        variant: "destructive"
      });
      return;
    }

    if (pinCode !== confirmPin) {
      toast({
        title: "PIN Mismatch",
        description: "PIN codes do not match",
        variant: "destructive"
      });
      return;
    }

    updateSetting('pinCode', pinCode);
    setPinCode('****');
    setConfirmPin('');
    
    toast({
      title: "PIN Set Successfully",
      description: "Your app is now protected with a PIN code"
    });
  };

  const handleClearData = () => {
    if (confirm('Are you sure you want to clear all app data? This cannot be undone.')) {
      storageService.clearAllData();
      setSettings(storageService.getSettings());
      
      toast({
        title: "Data Cleared",
        description: "All app data has been removed"
      });
    }
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      <div className="bg-foreground text-background p-4">
        <div className="flex items-center gap-2">
          <SettingsIcon className="w-6 h-6" />
          <h1 className="text-xl font-bold">Settings & Privacy</h1>
        </div>
      </div>

      <div className="p-4 space-y-4">
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Lock className="w-4 h-4" />
              Security & Privacy
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <Label htmlFor="fingerprint">Fingerprint Authentication</Label>
                <p className="text-xs text-muted-foreground">
                  Use biometric authentication to unlock app
                </p>
              </div>
              <Switch
                id="fingerprint"
                checked={settings.fingerprintEnabled}
                onCheckedChange={(checked) => updateSetting('fingerprintEnabled', checked)}
              />
            </div>

            <Separator />

            <div className="space-y-2">
              <Label>PIN Code Protection</Label>
              <div className="flex gap-2">
                <Input
                  type="password"
                  placeholder="Enter PIN"
                  value={pinCode}
                  onChange={(e) => setPinCode(e.target.value)}
                  maxLength={6}
                />
                <Input
                  type="password"
                  placeholder="Confirm PIN"
                  value={confirmPin}
                  onChange={(e) => setConfirmPin(e.target.value)}
                  maxLength={6}
                />
              </div>
              <Button size="sm" onClick={handleSetPin} className="w-full">
                Set PIN Code
              </Button>
              {settings.pinCode && (
                <Badge variant="outline" className="text-xs">
                  <Shield className="w-3 h-3 mr-1" />
                  PIN Protection Active
                </Badge>
              )}
            </div>

            <Separator />

            <div className="flex items-center justify-between">
              <div className="flex-1">
                <Label htmlFor="calculator">Calculator Mode</Label>
                <p className="text-xs text-muted-foreground">
                  Disguise app as a calculator for privacy
                </p>
              </div>
              <Switch
                id="calculator"
                checked={settings.calculatorModeEnabled}
                onCheckedChange={(checked) => updateSetting('calculatorModeEnabled', checked)}
              />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Mic className="w-4 h-4" />
              Voice Activation
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <Label htmlFor="voice">Enable Voice Activation</Label>
                <p className="text-xs text-muted-foreground">
                  Trigger SOS with voice commands
                </p>
              </div>
              <Switch
                id="voice"
                checked={settings.voiceActivationEnabled}
                onCheckedChange={(checked) => updateSetting('voiceActivationEnabled', checked)}
              />
            </div>

            {settings.voiceActivationEnabled && (
              <div className="space-y-2">
                <Label className="text-xs">Active Keywords</Label>
                <div className="flex flex-wrap gap-2">
                  {settings.voiceKeywords.map((keyword, idx) => (
                    <Badge key={idx} variant="secondary">
                      "{keyword}"
                    </Badge>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Smartphone className="w-4 h-4" />
              Emergency Features
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <Label htmlFor="shake">Shake Gesture Detection</Label>
                <p className="text-xs text-muted-foreground">
                  Trigger SOS by shaking device
                </p>
              </div>
              <Switch
                id="shake"
                checked={settings.shakeGestureEnabled}
                onCheckedChange={(checked) => updateSetting('shakeGestureEnabled', checked)}
              />
            </div>

            <Separator />

            <div className="flex items-center justify-between">
              <div className="flex-1">
                <Label htmlFor="recording" className="flex items-center gap-2">
                  <Video className="w-4 h-4" />
                  Auto Recording
                </Label>
                <p className="text-xs text-muted-foreground">
                  Automatically record video during SOS
                </p>
              </div>
              <Switch
                id="recording"
                checked={settings.autoRecordingEnabled}
                onCheckedChange={(checked) => updateSetting('autoRecordingEnabled', checked)}
              />
            </div>

            <Separator />

            <div className="flex items-center justify-between">
              <div className="flex-1">
                <Label htmlFor="flash" className="flex items-center gap-2">
                  <Zap className="w-4 h-4" />
                  Flash Alert
                </Label>
                <p className="text-xs text-muted-foreground">
                  Use camera flash for alerts
                </p>
              </div>
              <Switch
                id="flash"
                checked={settings.flashAlertEnabled}
                onCheckedChange={(checked) => updateSetting('flashAlertEnabled', checked)}
              />
            </div>

            <Separator />

            <div className="flex items-center justify-between">
              <div className="flex-1">
                <Label htmlFor="vibration" className="flex items-center gap-2">
                  <Vibrate className="w-4 h-4" />
                  Vibration Alerts
                </Label>
                <p className="text-xs text-muted-foreground">
                  Vibrate on threat detection
                </p>
              </div>
              <Switch
                id="vibration"
                checked={settings.vibrationEnabled}
                onCheckedChange={(checked) => updateSetting('vibrationEnabled', checked)}
              />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-warning/10 border-warning">
          <CardContent className="p-4">
            <h3 className="font-semibold text-sm mb-2 flex items-center gap-2">
              <Calculator className="w-4 h-4" />
              About Calculator Mode
            </h3>
            <p className="text-xs text-muted-foreground">
              When enabled, the app will display a calculator interface on launch. 
              Enter your PIN code followed by "=" to access the safety features. 
              This helps maintain privacy in sensitive situations.
            </p>
          </CardContent>
        </Card>

        <Card className="border-destructive">
          <CardContent className="p-4">
            <h3 className="font-semibold text-sm mb-2 text-destructive">
              Danger Zone
            </h3>
            <p className="text-xs text-muted-foreground mb-3">
              Clear all app data including guardians, settings, and SOS history. 
              This action cannot be undone.
            </p>
            <Button 
              variant="destructive" 
              size="sm" 
              className="w-full"
              onClick={handleClearData}
            >
              Clear All Data
            </Button>
          </CardContent>
        </Card>

        <div className="text-center text-xs text-muted-foreground py-4">
          <p>PanicSafe v1.0.0</p>
          <p className="mt-1">Your personal safety companion</p>
        </div>
      </div>

      <BottomNav />
    </div>
  );
}
