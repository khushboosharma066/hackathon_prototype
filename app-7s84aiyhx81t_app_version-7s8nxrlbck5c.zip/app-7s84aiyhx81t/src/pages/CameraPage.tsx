import { useState, useEffect, useRef } from 'react';
import { Camera as CameraIcon, SwitchCamera, Video, VideoOff } from 'lucide-react';
import BottomNav from '@/components/common/BottomNav';
import DangerLevelIndicator from '@/components/common/DangerLevelIndicator';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { cameraService } from '@/services/cameraService';
import { aiDetectionService } from '@/services/aiDetectionService';
import type { AIDetectionResult } from '@/types/panicsafe';

export default function CameraPage() {
  const [isActive, setIsActive] = useState(false);
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('user');
  const [detectionResult, setDetectionResult] = useState<AIDetectionResult | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const { toast } = useToast();

  useEffect(() => {
    return () => {
      if (isActive) {
        stopCamera();
      }
    };
  }, [isActive]);

  const startCamera = async () => {
    try {
      const stream = await cameraService.startCamera(facingMode);
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
      setIsActive(true);
      
      aiDetectionService.startMonitoring((result) => {
        setDetectionResult(result);
        
        if (result.dangerLevel === 'critical' && !isRecording) {
          handleThreatDetected();
        }
      });

      toast({
        title: "Camera Active",
        description: "AI threat detection is now monitoring"
      });
    } catch (error) {
      toast({
        title: "Camera Error",
        description: "Could not access camera. Please check permissions.",
        variant: "destructive"
      });
    }
  };

  const stopCamera = () => {
    cameraService.stopCamera();
    aiDetectionService.stopMonitoring();
    setIsActive(false);
    setDetectionResult(null);
    
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
  };

  const toggleCamera = async () => {
    if (isActive) {
      stopCamera();
      const newMode = facingMode === 'user' ? 'environment' : 'user';
      setFacingMode(newMode);
      setTimeout(() => startCamera(), 100);
    }
  };

  const handleThreatDetected = async () => {
    if (navigator.vibrate) {
      navigator.vibrate([200, 100, 200]);
    }

    setIsRecording(true);
    
    try {
      await cameraService.startRecording();
      
      setTimeout(async () => {
        const videoBlob = await cameraService.stopRecording();
        setIsRecording(false);
        console.log('Threat video recorded:', videoBlob.size, 'bytes');
        
        toast({
          title: "Threat Detected!",
          description: "10-second video recorded automatically",
          variant: "destructive"
        });
      }, 10000);
    } catch (error) {
      console.error('Recording failed:', error);
      setIsRecording(false);
    }
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      <div className="bg-foreground text-background p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CameraIcon className="w-6 h-6" />
            <h1 className="text-xl font-bold">AI Danger Camera</h1>
          </div>
          {isActive && (
            <Badge variant="destructive" className="animate-pulse">
              MONITORING
            </Badge>
          )}
        </div>
      </div>

      <div className="p-4 space-y-4">
        <div className="relative bg-black rounded-lg overflow-hidden aspect-video">
          <video
            ref={videoRef}
            autoPlay
            playsInline
            muted
            className="w-full h-full object-cover"
          />
          
          {!isActive && (
            <div className="absolute inset-0 flex items-center justify-center bg-muted">
              <div className="text-center">
                <CameraIcon className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
                <p className="text-muted-foreground">Camera inactive</p>
              </div>
            </div>
          )}

          {isRecording && (
            <div className="absolute top-4 right-4 flex items-center gap-2 bg-emergency text-emergency-foreground px-3 py-1 rounded-full animate-pulse">
              <Video className="w-4 h-4" />
              <span className="text-sm font-semibold">RECORDING</span>
            </div>
          )}
        </div>

        <div className="flex gap-2">
          <Button
            className="flex-1"
            onClick={isActive ? stopCamera : startCamera}
            variant={isActive ? "destructive" : "default"}
          >
            {isActive ? (
              <>
                <VideoOff className="w-4 h-4 mr-2" />
                Stop Camera
              </>
            ) : (
              <>
                <CameraIcon className="w-4 h-4 mr-2" />
                Start Camera
              </>
            )}
          </Button>

          {isActive && (
            <Button variant="outline" onClick={toggleCamera}>
              <SwitchCamera className="w-4 h-4" />
            </Button>
          )}
        </div>

        {detectionResult && (
          <>
            <DangerLevelIndicator
              level={detectionResult.dangerLevel}
              score={detectionResult.dangerScore}
              size="lg"
            />

            {detectionResult.threats.length > 0 && (
              <Card className="border-warning">
                <CardContent className="p-4">
                  <h3 className="font-semibold text-sm mb-2">Detected Threats:</h3>
                  <div className="space-y-2">
                    {detectionResult.threats.map((threat, idx) => (
                      <div key={idx} className="flex items-center justify-between text-sm">
                        <span className="capitalize">{threat.type}</span>
                        <Badge variant="outline">
                          {(threat.confidence * 100).toFixed(0)}% confident
                        </Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </>
        )}

        <Card className="bg-info/10 border-info">
          <CardContent className="p-4">
            <p className="text-sm text-muted-foreground">
              <strong>How it works:</strong> The AI continuously analyzes the camera feed 
              for potential threats. When danger is detected, the system automatically 
              records video evidence and can trigger an SOS alert if the threat level is critical.
            </p>
          </CardContent>
        </Card>
      </div>

      <BottomNav />
    </div>
  );
}
