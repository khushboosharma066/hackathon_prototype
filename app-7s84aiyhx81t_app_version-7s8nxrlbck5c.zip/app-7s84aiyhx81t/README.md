# Welcome to Your Miaoda Project
Miaoda Application Link URL
    URL:https://medo.dev/projects/app-7s84aiyhx81t

# PanicSafe - Women's Safety Mobile App

A comprehensive women's safety application featuring AI-powered danger prediction, emergency response system, and real-time guardian tracking.

## Features

### 🚨 Dual SOS Trigger System
- Large, prominent SOS button on home screen
- Voice activation with keywords: "Help me", "Save me", "Emergency"
- 3-second countdown mechanism to prevent accidental triggers
- Automatic location sharing with guardians
- Background audio/video recording during emergencies

### 📹 AI Danger Prediction Camera
- Real-time threat detection using camera feed
- Detects potential dangers:
  - Strangers in close proximity
  - Following behavior patterns
  - Aggressive facial expressions
  - Weapon gesture recognition
  - Suspicious group activities
- Automatic response when danger threshold exceeded
- 10-second automatic video recording on threat detection

### 👥 Guardian Contact Management
- Add/remove trusted guardian contacts
- One-tap live location sharing
- Real-time location tracking
- Emergency notifications via SMS/email

### 🗺️ Map & Safe Zone Navigator
- Display nearest safety locations:
  - Police stations
  - Hospitals
  - Public safe hubs
- Auto-navigation to selected safe zones
- Distance calculation and routing
- Crime heatmap visualization

### 📞 Fake Call System
- Realistic incoming call simulation
- Customizable contact names
- Authentic UI with ringtone and vibration
- Delayed trigger options
- Quick escape from uncomfortable situations

### ⚙️ Privacy & Security
- PIN code protection
- Fingerprint authentication support
- Calculator mode to disguise app
- Encrypted local storage
- Voice activation controls
- Shake gesture detection

## Technology Stack

- **Frontend**: React 18 + TypeScript
- **Styling**: Tailwind CSS
- **UI Components**: shadcn/ui
- **Routing**: React Router v6
- **Build Tool**: Vite
- **State Management**: React Hooks + Local Storage

## Project Structure

```
src/
 components/
   ├── common/
   │   ├── BottomNav.tsx          # Bottom navigation bar
   │   ├── EmergencyButton.tsx    # SOS button component
   │   └── DangerLevelIndicator.tsx # Threat level display
   └── ui/                         # shadcn/ui components
 pages/
   ├── HomePage.tsx                # Main dashboard
   ├── CameraPage.tsx              # AI camera interface
   ├── MapPage.tsx                 # Map and safe zones
   ├── GuardiansPage.tsx           # Guardian management
   ├── SettingsPage.tsx            # App settings
   └── FakeCallPage.tsx            # Fake call feature
 services/
   ├── locationService.ts          # Geolocation handling
   ├── cameraService.ts            # Camera and recording
   ├── storageService.ts           # Local data storage
   ├── sosService.ts               # Emergency SOS logic
   └── aiDetectionService.ts       # AI threat detection
 types/
   └── panicsafe.ts                # TypeScript definitions
 App.tsx                         # Main app component
 routes.tsx                      # Route configuration
 main.tsx                        # App entry point
```

## Key Services

### Location Service
- Real-time GPS tracking
- Distance calculation
- Location watching/monitoring
- High-accuracy positioning

### Camera Service
- Front/rear camera access
- Video recording
- Photo capture
- MediaStream management

### SOS Service
- Emergency countdown timer
- Guardian notification
- Backup server communication
- Flash and vibration alerts
- Automatic recording trigger

### AI Detection Service
- Threat detection simulation
- Danger score calculation
- Real-time monitoring
- ML model integration placeholders

### Storage Service
- Guardian contact management
- App settings persistence
- SOS event history
- Local data encryption

## Design System

### Color Scheme
- **Emergency Red**: `#FF0000` - SOS and critical alerts
- **Safe Green**: `#4CAF50` - Safe status indicators
- **Warning Yellow**: `#FFC107` - Medium threats
- **Info Blue**: `#2196F3` - Informational elements

### Danger Levels
- **Safe**: No threats detected (Green)
- **Low**: Minor concerns (Light Green)
- **Medium**: Potential threat (Yellow)
- **High**: Serious threat (Orange)
- **Critical**: Immediate danger (Red, pulsing)

## Browser Permissions Required

- **Location**: For GPS tracking and safe zone navigation
- **Camera**: For AI threat detection and emergency recording
- **Microphone**: For audio recording during emergencies
- **Vibration**: For alert notifications

## Development

### Prerequisites
- Node.js 18+ 
- npm or pnpm

### Installation
```bash
npm install
# or
pnpm install
```

### Development Server
```bash
npm run dev
# or
pnpm dev
```

### Build for Production
```bash
npm run build
# or
pnpm build
```

### Linting
```bash
npm run lint
# or
pnpm lint
```

## Implementation Notes

### AI Detection
The AI detection system currently uses simulated threat detection. For production:
1. Integrate TensorFlow.js or similar ML framework
2. Load pre-trained threat detection models
3. Implement real-time frame analysis
4. Add model optimization for mobile devices

### Emergency Notifications
The SOS notification system uses mock implementations. For production:
1. Integrate SMS gateway API (Twilio, etc.)
2. Set up email service (SendGrid, etc.)
3. Implement push notifications
4. Add backup server API endpoints

### Location Sharing
Real-time location sharing is implemented using browser Geolocation API. For production:
1. Add WebSocket for live tracking
2. Implement location history
3. Add geofencing capabilities
4. Optimize battery usage

## Security Considerations

- All sensitive data stored locally is encrypted
- PIN codes are hashed before storage
- Camera/microphone access requires explicit user permission
- Location data is only shared with authorized guardians
- Emergency recordings are stored securely

## Future Enhancements

- [ ] Routine anomaly detection with ML
- [ ] Police patrol zone integration
- [ ] Community safety reports
- [ ] Offline mode with SMS fallback
- [ ] Wearable device integration
- [ ] Multi-language support
- [ ] Dark mode optimization

## License

This project is built for safety and security purposes. Use responsibly.

## Support

For issues or feature requests, please contact the development team.

---

**PanicSafe** - Your Personal Safety Companion
