import { Shield, AlertTriangle, AlertCircle, Skull } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import type { DangerLevel } from '@/types/panicsafe';

interface DangerLevelIndicatorProps {
  level: DangerLevel;
  score?: number;
  size?: 'sm' | 'md' | 'lg';
}

export default function DangerLevelIndicator({ level, score, size = 'md' }: DangerLevelIndicatorProps) {
  const config = {
    safe: {
      color: 'bg-safe text-safe-foreground',
      icon: Shield,
      label: 'Safe',
      description: 'No threats detected'
    },
    low: {
      color: 'bg-danger-low text-white',
      icon: Shield,
      label: 'Low Risk',
      description: 'Minor concerns detected'
    },
    medium: {
      color: 'bg-danger-medium text-white',
      icon: AlertTriangle,
      label: 'Medium Risk',
      description: 'Potential threat detected'
    },
    high: {
      color: 'bg-danger-high text-white',
      icon: AlertCircle,
      label: 'High Risk',
      description: 'Serious threat detected'
    },
    critical: {
      color: 'bg-danger-critical text-white animate-pulse',
      icon: Skull,
      label: 'CRITICAL',
      description: 'Immediate danger!'
    }
  };

  const { color, icon: Icon, label, description } = config[level];

  const sizeClasses = {
    sm: 'text-xs p-2',
    md: 'text-sm p-3',
    lg: 'text-base p-4'
  };

  const iconSizes = {
    sm: 'w-4 h-4',
    md: 'w-5 h-5',
    lg: 'w-6 h-6'
  };

  return (
    <div className={`${color} ${sizeClasses[size]} rounded-lg flex items-center gap-3`}>
      <Icon className={iconSizes[size]} />
      <div className="flex-1">
        <div className="font-bold">{label}</div>
        <div className="text-xs opacity-90">{description}</div>
        {score !== undefined && (
          <div className="text-xs mt-1">Score: {score.toFixed(0)}%</div>
        )}
      </div>
    </div>
  );
}
