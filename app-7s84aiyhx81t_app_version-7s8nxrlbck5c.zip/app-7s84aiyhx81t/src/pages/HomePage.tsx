import { Camera, Map, Phone, Users, Mic, Shield } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import BottomNav from '@/components/common/BottomNav';
import EmergencyButton from '@/components/common/EmergencyButton';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { storageService } from '@/services/storageService';

export default function HomePage() {
  const navigate = useNavigate();
  const guardians = storageService.getGuardians();
  const settings = storageService.getSettings();

  const features = [
    {
      icon: Camera,
      title: 'AI Camera',
      description: 'Threat detection',
      path: '/camera',
      color: 'text-info'
    },
    {
      icon: Map,
      title: 'Safe Zones',
      description: 'Find nearby help',
      path: '/map',
      color: 'text-success'
    },
    {
      icon: Phone,
      title: 'Fake Call',
      description: 'Exit situations',
      path: '/fake-call',
      color: 'text-warning'
    },
    {
      icon: Users,
      title: 'Guardians',
      description: `${guardians.length} contacts`,
      path: '/guardians',
      color: 'text-primary'
    }
  ];

  return (
    <div className="min-h-screen bg-background pb-20">
      <div className="bg-emergency text-emergency-foreground p-6 text-center">
        <h1 className="text-2xl font-bold mb-2">PanicSafe</h1>
        <p className="text-sm opacity-90">Your Personal Safety Companion</p>
      </div>

      <div className="p-6 space-y-6">
        <div className="flex flex-col items-center">
          <EmergencyButton size="lg" />
          <p className="text-center text-sm text-muted-foreground mt-4">
            Press and hold for 3 seconds to trigger emergency alert
          </p>
        </div>

        {settings.voiceActivationEnabled && (
          <Card className="bg-info/10 border-info">
            <CardContent className="p-4 flex items-center gap-3">
              <Mic className="w-5 h-5 text-info" />
              <div className="flex-1">
                <p className="text-sm font-semibold">Voice Activation Active</p>
                <p className="text-xs text-muted-foreground">
                  Say "Help me" or "Emergency" to trigger SOS
                </p>
              </div>
              <Badge variant="secondary">ON</Badge>
            </CardContent>
          </Card>
        )}

        <div>
          <h2 className="text-lg font-semibold mb-3">Quick Access</h2>
          <div className="grid grid-cols-2 gap-3">
            {features.map((feature) => {
              const Icon = feature.icon;
              return (
                <Card
                  key={feature.path}
                  className="cursor-pointer hover:shadow-lg transition-shadow"
                  onClick={() => navigate(feature.path)}
                >
                  <CardContent className="p-4 flex flex-col items-center text-center">
                    <Icon className={`w-8 h-8 mb-2 ${feature.color}`} />
                    <h3 className="font-semibold text-sm">{feature.title}</h3>
                    <p className="text-xs text-muted-foreground mt-1">
                      {feature.description}
                    </p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <Shield className="w-5 h-5 text-safe mt-1" />
              <div>
                <h3 className="font-semibold text-sm mb-1">Safety Tips</h3>
                <ul className="text-xs text-muted-foreground space-y-1">
                  <li>• Keep location services enabled</li>
                  <li>• Add trusted guardians to your contact list</li>
                  <li>• Test features regularly to ensure they work</li>
                  <li>• Stay in well-lit, populated areas when possible</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="flex items-center justify-between text-sm">
          <span className="text-muted-foreground">
            {guardians.length} Guardian{guardians.length !== 1 ? 's' : ''} Active
          </span>
          <Badge variant="outline" className="text-safe border-safe">
            System Ready
          </Badge>
        </div>
      </div>

      <BottomNav />
    </div>
  );
}
