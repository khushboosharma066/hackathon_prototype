import { useState, useEffect } from 'react';
import { Users, Plus, Trash2, Phone, Mail, MapPin, Share2 } from 'lucide-react';
import BottomNav from '@/components/common/BottomNav';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { storageService } from '@/services/storageService';
import { locationService } from '@/services/locationService';
import type { GuardianContact } from '@/types/panicsafe';

export default function GuardiansPage() {
  const [guardians, setGuardians] = useState<GuardianContact[]>([]);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isSharing, setIsSharing] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    loadGuardians();
  }, []);

  const loadGuardians = () => {
    const loaded = storageService.getGuardians();
    setGuardians(loaded);
  };

  const handleAddGuardian = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    const newGuardian: GuardianContact = {
      id: crypto.randomUUID(),
      name: formData.get('name') as string,
      phone: formData.get('phone') as string,
      email: formData.get('email') as string || undefined,
      relationship: formData.get('relationship') as string,
      isSharing: false,
      addedAt: new Date()
    };

    storageService.addGuardian(newGuardian);
    loadGuardians();
    setIsAddDialogOpen(false);
    
    toast({
      title: "Guardian Added",
      description: `${newGuardian.name} has been added to your guardian list`
    });
  };

  const handleRemoveGuardian = (id: string, name: string) => {
    storageService.removeGuardian(id);
    loadGuardians();
    
    toast({
      title: "Guardian Removed",
      description: `${name} has been removed from your guardian list`
    });
  };

  const toggleSharing = (id: string, currentState: boolean) => {
    storageService.updateGuardian(id, { isSharing: !currentState });
    loadGuardians();
    
    toast({
      title: currentState ? "Sharing Disabled" : "Sharing Enabled",
      description: currentState 
        ? "Location sharing has been disabled for this guardian"
        : "Location sharing has been enabled for this guardian"
    });
  };

  const shareLocationWithAll = async () => {
    try {
      const location = await locationService.getCurrentLocation();
      setIsSharing(true);
      
      locationService.startWatchingLocation((loc) => {
        console.log('Sharing location:', loc);
      });

      toast({
        title: "Location Sharing Active",
        description: "Your live location is being shared with all guardians"
      });
    } catch (error) {
      toast({
        title: "Location Error",
        description: "Could not access your location",
        variant: "destructive"
      });
    }
  };

  const stopSharingLocation = () => {
    locationService.stopWatchingLocation();
    setIsSharing(false);
    
    toast({
      title: "Location Sharing Stopped",
      description: "Location sharing has been disabled"
    });
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      <div className="bg-foreground text-background p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Users className="w-6 h-6" />
            <h1 className="text-xl font-bold">Guardian Contacts</h1>
          </div>
          <Badge variant="secondary">
            {guardians.length} Contact{guardians.length !== 1 ? 's' : ''}
          </Badge>
        </div>
      </div>

      <div className="p-4 space-y-4">
        <div className="flex gap-2">
          <Button
            className="flex-1"
            onClick={isSharing ? stopSharingLocation : shareLocationWithAll}
            variant={isSharing ? "destructive" : "default"}
          >
            {isSharing ? (
              <>
                <MapPin className="w-4 h-4 mr-2" />
                Stop Sharing Location
              </>
            ) : (
              <>
                <Share2 className="w-4 h-4 mr-2" />
                Share Live Location
              </>
            )}
          </Button>

          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="outline">
                <Plus className="w-4 h-4" />
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add Guardian Contact</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleAddGuardian} className="space-y-4">
                <div>
                  <Label htmlFor="name">Name *</Label>
                  <Input
                    id="name"
                    name="name"
                    placeholder="Enter name"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="phone">Phone Number *</Label>
                  <Input
                    id="phone"
                    name="phone"
                    type="tel"
                    placeholder="+1 (555) 123-4567"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="email">Email (Optional)</Label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    placeholder="email@example.com"
                  />
                </div>
                <div>
                  <Label htmlFor="relationship">Relationship *</Label>
                  <Input
                    id="relationship"
                    name="relationship"
                    placeholder="e.g., Mother, Friend, Partner"
                    required
                  />
                </div>
                <Button type="submit" className="w-full">
                  Add Guardian
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {guardians.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center">
              <Users className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
              <h3 className="font-semibold mb-2">No Guardians Added</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Add trusted contacts who will be notified in case of emergency
              </p>
              <Button onClick={() => setIsAddDialogOpen(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Add Your First Guardian
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-3">
            {guardians.map((guardian) => (
              <Card key={guardian.id}>
                <CardContent className="p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-semibold">{guardian.name}</h3>
                        <Badge variant="outline" className="text-xs">
                          {guardian.relationship}
                        </Badge>
                      </div>
                      
                      <div className="space-y-1 text-sm">
                        <a 
                          href={`tel:${guardian.phone}`}
                          className="flex items-center gap-2 text-info hover:underline"
                        >
                          <Phone className="w-3 h-3" />
                          {guardian.phone}
                        </a>
                        
                        {guardian.email && (
                          <a 
                            href={`mailto:${guardian.email}`}
                            className="flex items-center gap-2 text-muted-foreground hover:underline"
                          >
                            <Mail className="w-3 h-3" />
                            {guardian.email}
                          </a>
                        )}
                      </div>

                      <div className="flex items-center gap-2 mt-3">
                        <Switch
                          checked={guardian.isSharing}
                          onCheckedChange={() => toggleSharing(guardian.id, guardian.isSharing)}
                        />
                        <span className="text-xs text-muted-foreground">
                          {guardian.isSharing ? "Sharing enabled" : "Sharing disabled"}
                        </span>
                      </div>
                    </div>

                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => handleRemoveGuardian(guardian.id, guardian.name)}
                    >
                      <Trash2 className="w-4 h-4 text-destructive" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        <Card className="bg-info/10 border-info">
          <CardContent className="p-4">
            <p className="text-sm text-muted-foreground">
              <strong>About Guardians:</strong> Your guardian contacts will receive 
              emergency alerts with your location when you trigger SOS. They can also 
              track your live location when sharing is enabled. Choose people you trust 
              who can respond quickly in emergencies.
            </p>
          </CardContent>
        </Card>
      </div>

      <BottomNav />
    </div>
  );
}
