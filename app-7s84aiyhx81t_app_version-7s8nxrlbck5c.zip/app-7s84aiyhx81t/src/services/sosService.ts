import type { Location, SOSEvent, DangerLevel } from '@/types/panicsafe';
import { locationService } from './locationService';
import { cameraService } from './cameraService';
import { storageService } from './storageService';

class SOSService {
  private countdownTimer: NodeJS.Timeout | null = null;
  private countdownCallback: ((remaining: number) => void) | null = null;

  async triggerSOS(dangerLevel: DangerLevel = 'critical'): Promise<void> {
    try {
      // Get current location
      const location = await locationService.getCurrentLocation();
      
      // Get guardians
      const guardians = storageService.getGuardians();
      const activeGuardians = guardians.filter(g => g.isSharing);
      
      // Create SOS event
      const event: SOSEvent = {
        id: crypto.randomUUID(),
        timestamp: new Date(),
        location,
        guardians: activeGuardians.map(g => g.id),
        dangerLevel,
        resolved: false,
        videoRecorded: false,
        audioRecorded: false
      };

      // Notify guardians
      await this.notifyGuardians(activeGuardians, location);
      
      // Send to backup server (mock)
      await this.sendToBackupServer(event);
      
      // Start emergency recording
      await this.startEmergencyRecording();
      
      // Trigger flash and vibration
      this.triggerFlashAlert();
      this.triggerVibration();
      
      // Save event
      storageService.addSOSEvent(event);
      
      console.log('SOS triggered successfully', event);
    } catch (error) {
      console.error('SOS trigger failed:', error);
      throw error;
    }
  }

  startCountdown(seconds: number, callback: (remaining: number) => void): void {
    this.stopCountdown();
    
    let remaining = seconds;
    this.countdownCallback = callback;
    
    callback(remaining);
    
    this.countdownTimer = setInterval(() => {
      remaining--;
      callback(remaining);
      
      if (remaining <= 0) {
        this.stopCountdown();
        this.triggerSOS();
      }
    }, 1000);
  }

  stopCountdown(): void {
    if (this.countdownTimer) {
      clearInterval(this.countdownTimer);
      this.countdownTimer = null;
    }
    if (this.countdownCallback) {
      this.countdownCallback = null;
    }
  }

  private async notifyGuardians(guardians: { name: string; phone: string; email?: string }[], location: Location): Promise<void> {
    // Mock SMS/Email notification
    const message = `EMERGENCY ALERT from PanicSafe!\nLocation: ${location.latitude}, ${location.longitude}\nTime: ${new Date().toLocaleString()}\nPlease check immediately!`;
    
    guardians.forEach(guardian => {
      console.log(`Sending SMS to ${guardian.phone}:`, message);
      if (guardian.email) {
        console.log(`Sending email to ${guardian.email}:`, message);
      }
    });
    
    // In production, this would call actual SMS/email APIs
    return Promise.resolve();
  }

  private async sendToBackupServer(event: SOSEvent): Promise<void> {
    // Mock API call to backup server
    console.log('Sending to backup server:', event);
    
    // In production, this would be:
    // await fetch('/api/sos/emergency', {
    //   method: 'POST',
    //   headers: { 'Content-Type': 'application/json' },
    //   body: JSON.stringify(event)
    // });
    
    return Promise.resolve();
  }

  private async startEmergencyRecording(): Promise<void> {
    const settings = storageService.getSettings();
    
    if (settings.autoRecordingEnabled) {
      try {
        await cameraService.startCamera('user');
        await cameraService.startRecording();
        
        // Auto-stop after 30 seconds
        setTimeout(async () => {
          try {
            const videoBlob = await cameraService.stopRecording();
            console.log('Emergency video recorded:', videoBlob.size, 'bytes');
            // In production, upload to secure storage
          } catch (error) {
            console.error('Recording stop failed:', error);
          }
        }, 30000);
      } catch (error) {
        console.error('Emergency recording failed:', error);
      }
    }
  }

  private triggerFlashAlert(): void {
    const settings = storageService.getSettings();
    
    if (settings.flashAlertEnabled) {
      // Flash pattern: on-off-on-off-on
      console.log('Flash alert triggered');
      // In production, use torch API if available
    }
  }

  private triggerVibration(): void {
    const settings = storageService.getSettings();
    
    if (settings.vibrationEnabled && navigator.vibrate) {
      // Vibration pattern: long-short-long-short-long
      navigator.vibrate([500, 200, 500, 200, 500]);
    }
  }
}

export const sosService = new SOSService();
