import { useState } from 'react';
import { Phone, PhoneOff, User, Clock, Volume2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

export default function FakeCallPage() {
  const navigate = useNavigate();
  const [isCallActive, setIsCallActive] = useState(false);
  const [contactName, setContactName] = useState('Mom');
  const [delaySeconds, setDelaySeconds] = useState(5);
  const [countdown, setCountdown] = useState<number | null>(null);

  const presetContacts = [
    { name: 'Mom', icon: '👩' },
    { name: 'Dad', icon: '👨' },
    { name: 'Police Officer', icon: '👮' },
    { name: 'Boss', icon: '💼' },
    { name: 'Friend', icon: '👤' }
  ];

  const startFakeCall = () => {
    let remaining = delaySeconds;
    setCountdown(remaining);

    const timer = setInterval(() => {
      remaining--;
      setCountdown(remaining);

      if (remaining <= 0) {
        clearInterval(timer);
        setCountdown(null);
        triggerCall();
      }
    }, 1000);
  };

  const triggerCall = () => {
    setIsCallActive(true);
    
    if (navigator.vibrate) {
      const pattern = [500, 200, 500, 200, 500];
      const vibrate = () => {
        navigator.vibrate(pattern);
        if (isCallActive) {
          setTimeout(vibrate, 2000);
        }
      };
      vibrate();
    }
  };

  const answerCall = () => {
    setIsCallActive(false);
    navigate('/');
  };

  const rejectCall = () => {
    setIsCallActive(false);
  };

  if (isCallActive) {
    return (
      <div className="min-h-screen bg-foreground text-background flex flex-col items-center justify-between p-8">
        <div className="flex-1 flex flex-col items-center justify-center">
          <div className="w-32 h-32 rounded-full bg-muted flex items-center justify-center mb-6 text-6xl">
            {presetContacts.find(c => c.name === contactName)?.icon || '👤'}
          </div>
          
          <h1 className="text-3xl font-bold mb-2">{contactName}</h1>
          <p className="text-lg text-muted-foreground mb-8">Incoming call...</p>

          <div className="flex items-center gap-2 text-muted-foreground mb-4">
            <Volume2 className="w-5 h-5 animate-pulse" />
            <span className="text-sm">Ringing...</span>
          </div>
        </div>

        <div className="w-full max-w-sm space-y-4">
          <Button
            size="lg"
            className="w-full bg-safe hover:bg-safe/90 text-safe-foreground"
            onClick={answerCall}
          >
            <Phone className="w-6 h-6 mr-2" />
            Answer
          </Button>
          
          <Button
            size="lg"
            variant="destructive"
            className="w-full"
            onClick={rejectCall}
          >
            <PhoneOff className="w-6 h-6 mr-2" />
            Decline
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="bg-foreground text-background p-4">
        <div className="flex items-center gap-2">
          <Phone className="w-6 h-6" />
          <h1 className="text-xl font-bold">Fake Call System</h1>
        </div>
      </div>

      <div className="p-4 space-y-4">
        <Card>
          <CardContent className="p-6 space-y-4">
            <div>
              <Label htmlFor="contact">Select Contact</Label>
              <div className="grid grid-cols-2 gap-2 mt-2">
                {presetContacts.map((contact) => (
                  <Button
                    key={contact.name}
                    variant={contactName === contact.name ? "default" : "outline"}
                    className="h-auto py-3"
                    onClick={() => setContactName(contact.name)}
                  >
                    <span className="text-2xl mr-2">{contact.icon}</span>
                    {contact.name}
                  </Button>
                ))}
              </div>
            </div>

            <div>
              <Label htmlFor="custom">Or Enter Custom Name</Label>
              <Input
                id="custom"
                placeholder="Enter contact name"
                value={contactName}
                onChange={(e) => setContactName(e.target.value)}
                className="mt-2"
              />
            </div>

            <div>
              <Label htmlFor="delay">Call Delay</Label>
              <Select
                value={delaySeconds.toString()}
                onValueChange={(value) => setDelaySeconds(Number(value))}
              >
                <SelectTrigger className="mt-2">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="0">Immediate</SelectItem>
                  <SelectItem value="5">5 seconds</SelectItem>
                  <SelectItem value="10">10 seconds</SelectItem>
                  <SelectItem value="15">15 seconds</SelectItem>
                  <SelectItem value="30">30 seconds</SelectItem>
                  <SelectItem value="60">1 minute</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {countdown !== null && (
          <Card className="bg-warning/10 border-warning animate-pulse">
            <CardContent className="p-6 text-center">
              <Clock className="w-12 h-12 mx-auto mb-3 text-warning" />
              <p className="text-2xl font-bold mb-2">{countdown}</p>
              <p className="text-sm text-muted-foreground">
                Incoming call in {countdown} second{countdown !== 1 ? 's' : ''}...
              </p>
            </CardContent>
          </Card>
        )}

        <Button
          size="lg"
          className="w-full"
          onClick={startFakeCall}
          disabled={countdown !== null}
        >
          <Phone className="w-5 h-5 mr-2" />
          {countdown !== null ? 'Call Scheduled...' : 'Trigger Fake Call'}
        </Button>

        <Card className="bg-info/10 border-info">
          <CardContent className="p-4">
            <h3 className="font-semibold text-sm mb-2">How to Use</h3>
            <ul className="text-xs text-muted-foreground space-y-1">
              <li>• Select or enter a contact name</li>
              <li>• Choose when the call should appear</li>
              <li>• Use this to exit uncomfortable situations</li>
              <li>• The call looks and sounds realistic</li>
              <li>• You can also trigger via voice command or shake gesture</li>
            </ul>
          </CardContent>
        </Card>

        <div className="grid grid-cols-3 gap-2">
          <Card className="bg-muted">
            <CardContent className="p-3 text-center">
              <User className="w-6 h-6 mx-auto mb-1 text-muted-foreground" />
              <p className="text-xs font-semibold">Realistic</p>
              <p className="text-xs text-muted-foreground">Authentic UI</p>
            </CardContent>
          </Card>
          <Card className="bg-muted">
            <CardContent className="p-3 text-center">
              <Volume2 className="w-6 h-6 mx-auto mb-1 text-muted-foreground" />
              <p className="text-xs font-semibold">Ringtone</p>
              <p className="text-xs text-muted-foreground">With vibration</p>
            </CardContent>
          </Card>
          <Card className="bg-muted">
            <CardContent className="p-3 text-center">
              <Clock className="w-6 h-6 mx-auto mb-1 text-muted-foreground" />
              <p className="text-xs font-semibold">Timed</p>
              <p className="text-xs text-muted-foreground">Delayed trigger</p>
            </CardContent>
          </Card>
        </div>

        <Button
          variant="outline"
          className="w-full"
          onClick={() => navigate('/')}
        >
          Back to Home
        </Button>
      </div>
    </div>
  );
}
